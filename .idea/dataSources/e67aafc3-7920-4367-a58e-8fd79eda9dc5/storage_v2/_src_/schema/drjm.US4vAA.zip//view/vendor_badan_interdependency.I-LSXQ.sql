create definer = `skip-grants user`@`skip-grants host` view vendor_badan_interdependency as
select `drjm`.`vendors`.`id`                     AS `vendor_id`,
       `drjm`.`vendors`.`jenis_vendor_id`        AS `jenis_vendor_id`,
       `drjm`.`users`.`name`                     AS `vendor_name`,
       `drjm`.`vendor_informasi_pemiliks`.`ktp`  AS `ktp`,
       `drjm`.`vendor_informasi_pemiliks`.`name` AS `name`,
       `drjm`.`vendor_informasi_pemiliks`.`kk`   AS `kk`,
       cast('Pemilik' as char charset utf8mb4)   AS `role`
from ((`drjm`.`vendors` left join `drjm`.`vendor_informasi_pemiliks` on ((
        `drjm`.`vendor_informasi_pemiliks`.`vendor_id` = `drjm`.`vendors`.`id`)))
         left join `drjm`.`users` on ((`drjm`.`users`.`id` = `drjm`.`vendors`.`user_id`)))
where (`drjm`.`vendors`.`jenis_vendor_id` = 1)
union
select `drjm`.`vendors`.`id`                            AS `vendor_id`,
       `drjm`.`vendors`.`jenis_vendor_id`               AS `jenis_vendor_id`,
       `drjm`.`users`.`name`                            AS `vendor_name`,
       `drjm`.`vendor_informasi_penguruses`.`nomor_ktp` AS `ktp`,
       `drjm`.`vendor_informasi_penguruses`.`name`      AS `name`,
       `drjm`.`vendor_informasi_penguruses`.`nomor_kk`  AS `kk`,
       cast('Pengurus' as char charset utf8mb4)         AS `role`
from ((`drjm`.`vendors` left join `drjm`.`vendor_informasi_penguruses` on ((
        `drjm`.`vendor_informasi_penguruses`.`vendor_id` = `drjm`.`vendors`.`id`)))
         left join `drjm`.`users` on ((`drjm`.`users`.`id` = `drjm`.`vendors`.`user_id`)))
where (`drjm`.`vendors`.`jenis_vendor_id` = 1)
union
select `drjm`.`vendors`.`id`                           AS `vendor_id`,
       `drjm`.`vendors`.`jenis_vendor_id`              AS `jenis_vendor_id`,
       `drjm`.`users`.`name`                           AS `vendor_name`,
       `drjm`.`vendor_informasi_tenaga_ahlis`.`no_ktp` AS `ktp`,
       `drjm`.`vendor_informasi_tenaga_ahlis`.`nama`   AS `name`,
       `drjm`.`vendor_informasi_tenaga_ahlis`.`no_kk`  AS `kk`,
       cast('Tenaga Ahli' as char charset utf8mb4)     AS `role`
from ((`drjm`.`vendors` left join `drjm`.`vendor_informasi_tenaga_ahlis` on ((
        `drjm`.`vendor_informasi_tenaga_ahlis`.`vendor_id` = `drjm`.`vendors`.`id`)))
         left join `drjm`.`users` on ((`drjm`.`users`.`id` = `drjm`.`vendors`.`user_id`)))
where (`drjm`.`vendors`.`jenis_vendor_id` = 1)
union
select `drjm`.`vendors`.`id`                             AS `vendor_id`,
       `drjm`.`vendors`.`jenis_vendor_id`                AS `jenis_vendor_id`,
       `drjm`.`users`.`name`                             AS `vendor_name`,
       `drjm`.`vendors`.`ktp`                            AS `ktp`,
       `drjm`.`users`.`name`                             AS `name`,
       `drjm`.`vendors`.`kk`                             AS `kk`,
       cast('Vendor Perorangan' as char charset utf8mb4) AS `role`
from (`drjm`.`vendors`
         left join `drjm`.`users` on ((`drjm`.`users`.`id` = `drjm`.`vendors`.`user_id`)))
where (`drjm`.`vendors`.`jenis_vendor_id` = 2);

